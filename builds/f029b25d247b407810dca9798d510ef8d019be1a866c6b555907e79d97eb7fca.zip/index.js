exports.handler = async (event) => {
    // Проверим метод запроса
    if (event.httpMethod === 'GET') {
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'GET запрос успешно обработан',
            }),
        };
    } else if (event.httpMethod === 'POST') {
        // Обработка POST запроса
        let body = JSON.parse(event.body);
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'POST запрос успешно обработан',
                data: body,
            }),
        };
    } else {
        return {
            statusCode: 405,
            body: JSON.stringify({
                message: 'Метод не поддерживается',
            }),
        };
    }
};
